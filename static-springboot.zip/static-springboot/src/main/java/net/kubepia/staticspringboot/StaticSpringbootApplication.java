package net.kubepia.staticspringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StaticSpringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(StaticSpringbootApplication.class, args);
	}

}

package net.kubepia.staticspringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StaticSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
